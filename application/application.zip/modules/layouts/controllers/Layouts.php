<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Layouts extends MX_Controller {
	
  public function index()
  {
  	$this->load->library('template');
  }
}

//end
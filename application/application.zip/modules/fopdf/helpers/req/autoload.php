<?php
//define('FPDF_FONTPATH','fonts/');
require('tfpdf/tfpdf.php');
require('rotation/rotation.php');
?>